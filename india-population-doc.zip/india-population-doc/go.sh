#!/usr/bin/env bash
set -x
cd /c/Users/runneradmin/Desktop/india-population-doc
python t.py
python probe.py
