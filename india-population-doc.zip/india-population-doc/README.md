# Population Rising — India's Demographic Decade

A ~3½-minute documentary video about India's population growth: how it
accelerated, why it is slowing, what the peak looks like, and what the number
requires.

Everything is generated from source — no stock footage, no external assets.

## What you get

| File | What it is |
|---|---|
| `Population-Rising-India.mp4` | The finished 1080p (1280×720) video, H.264 + AAC, burned-in subtitles |
| `work/subtitles.srt` | The narration as a subtitle file |
| `work/narration.wav` | The voice track on its own |
| `work/music.wav` | The generated ambient bed on its own |
| `content.py` | Every figure, and the narration script, in one place |
| `SCRIPT.md` | The narration as a readable document |

## How it is built

```
content.py ──> build_audio.py ──> tts_request.json ──> synth.ps1 (Windows SAPI)
                                                              │
                                                              ▼
                                                            wav/*.wav
                                                              │
timeline.py <────────────────────────────────────────────────┘
    │
    ├──> timeline.json ──> render.py ──> work/frames/f00000.png ...
    ├──> narration.wav
    └──> subtitles.srt
                 │
                 ▼
         music.py  ──> music.wav
                 │
                 ▼
          assemble.py ──> Population-Rising-India.mp4
```

## Build it yourself

```bash
cd india-population-doc
powershell -ExecutionPolicy Bypass -File build.ps1
```

or step by step:

```bash
python build_audio.py voices.json work
powershell -NoProfile -ExecutionPolicy Bypass -File synth.ps1 -InFile work/tts_request.json -OutDir work/wav
python timeline.py work work/timeline.json work/narration.wav
python render.py work/timeline.json work/frames
python music.py work/narration.wav work/music.wav
python assemble.py work work/timeline.json work/narration.wav Population-Rising-India.mp4
```

Requirements: Python 3.9+ with `Pillow`, `numpy`, `imageio-ffmpeg`; Windows
PowerShell (for the SAPI voice); `ffmpeg` (auto-detected, or via
`imageio-ffmpeg`).

## The voice

`synth.ps1` uses the Windows built-in speech engine. It prints the voices it
finds and picks the first of: Microsoft David / Mark / Zira Desktop, then the
plain David / Zira / Mark, then Ravi, then anything else installed. To pick a
specific one, set `"voice": "Microsoft David Desktop"` in `voices.json`.
`"rate": -1` slows the narration down; `0` is the default pace.

## Editing the video

All the content lives in `content.py`:

* `SCENES` — the narration, one sentence per list entry. Each sentence becomes
  one TTS clip and one subtitle cue, so the visuals, the voice and the
  subtitles stay in sync automatically.
* `CENSUS`, `TFR`, `STATE_TFR_NFHS5`, `PYRAMID`, `TRAJECTORY` — the data that
  the charts are drawn from.

Change a number, re-run `build.ps1`, and the chart, the voice and the caption
all update together.

## Sources

* UN World Population Prospects 2024 revision — population, projections,
  median age, urbanisation
* Census of India 1951–2011 — decennial totals
* Sample Registration System — total fertility rate
* NFHS-5 (2019–21) — state-level fertility
* Economic Survey 2023–24 — monthly job creation requirement
* UN-Habitat / World Bank — urbanisation and urban growth

Every chart carries its own source line on screen.
