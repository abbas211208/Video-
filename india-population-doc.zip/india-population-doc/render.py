"""
Render every frame of "Population Rising" with Pillow.

  python render.py <timeline.json> <frames_dir>

Every visual beat is tied to the narration: `c.beat` is the index of the
sentence currently being spoken and `c.bp` is the progress through it, so
charts reveal themselves in step with the voice.
"""
import json
import math
import os
import sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter

from content import (CENSUS, CREDITS, DECADE_DELTA, OUTRO, POP_PEAK,
                     POP_PEAK_YEAR, PYRAMID, REPLACEMENT, STATE_TFR_NFHS5,
                     TRAJECTORY)

W, H = 1280, 720
FPS = 24

# ------------------------------------------------------------------ palette
BG_TOP = (10, 14, 28)
BG_BOT = (19, 26, 48)
INK = (244, 246, 251)
MUTED = (139, 152, 182)
DIM = (86, 98, 126)
SAFFRON = (255, 153, 51)
SAFFRON_D = (226, 112, 58)
TEAL = (45, 212, 191)
BLUE = (96, 165, 250)
RED = (239, 68, 68)
GOLD = (250, 204, 21)

FONT_DIR = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
_FCACHE = {}
REG, BOLD, SEMI = "segoeui.ttf", "segoeuib.ttf", "seguisb.ttf"


def F(size, style=REG):
    key = (style, size)
    if key not in _FCACHE:
        try:
            _FCACHE[key] = ImageFont.truetype(os.path.join(FONT_DIR, style), size)
        except Exception:
            _FCACHE[key] = ImageFont.load_default()
    return _FCACHE[key]


# ------------------------------------------------------------------ helpers
def clamp(x, a=0.0, b=1.0):
    return a if x < a else (b if x > b else x)


def lerp(a, b, t):
    return a + (b - a) * t


def ease_out(t):
    t = clamp(t)
    return 1 - (1 - t) ** 3


def ease_in_out(t):
    t = clamp(t)
    return 4 * t * t * t if t < 0.5 else 1 - ((-2 * t + 2) ** 3) / 2


def mix(c1, c2, t):
    t = clamp(t)
    return tuple(int(round(lerp(c1[i], c2[i], t))) for i in range(3))


def alpha(c, a):
    return (c[0], c[1], c[2], int(clamp(a) * 255))


def text_w(draw, s, f):
    return draw.textbbox((0, 0), s, font=f)[2]


def wrap(draw, s, f, max_w):
    words, lines, cur = s.split(), [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if text_w(draw, trial, f) <= max_w or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def draw_lines(draw, lines, xy, f, fill, anchor="la", spacing=6):
    x, y = xy
    lh = f.size * 1.32 + spacing
    for i, ln in enumerate(lines):
        draw.text((x, y + i * lh), ln, font=f, fill=fill, anchor=anchor)
    return y + len(lines) * lh


def bg_gradient(t=0.0):
    """Deep blue vertical gradient with a slow drifting warm pool of light."""
    base = Image.new("RGB", (W, H), BG_TOP)
    d = ImageDraw.Draw(base)
    for y in range(H):
        k = y / H
        d.line([(0, y), (W, y)], fill=mix(BG_TOP, BG_BOT, k))

    gx = int(W * (0.50 + 0.16 * math.sin(t * 0.11)))
    gy = int(H * (0.40 + 0.09 * math.cos(t * 0.085)))

    ov = Image.new("RGB", (W, H), (0, 0, 0))
    od = ImageDraw.Draw(ov)
    for r in range(560, 0, -10):
        k = (1 - r / 560.0) ** 2
        od.ellipse([gx - r, gy - r, gx + r, gy + r],
                   fill=(int(58 * k), int(34 * k), int(12 * k)))
    ov = ov.filter(ImageFilter.GaussianBlur(50))
    return Image.merge("RGB", [
        base.split()[i].point(lambda v, cb=ov.split()[i]: min(255, v + cb))
        for i in range(3)])


# ------------------------------------------------------------------ chrome
def header(draw, kicker, title, a=1.0):
    if a <= 0.01:
        return
    x, y = 74, 52
    if kicker:
        f = F(18, SEMI)
        xx = x
        for ch in kicker:
            draw.text((xx, y), ch, font=f, fill=alpha(SAFFRON, a))
            xx += draw.textlength(ch, font=f) + 2.6
        y += 29
    if title:
        f = F(42, BOLD)
        lines = wrap(draw, title, f, W - 148)
        for i, ln in enumerate(lines):
            draw.text((x, y + i * 51), ln, font=f, fill=alpha(INK, a))
        y += 51 * len(lines)
    draw.rectangle([x, y + 13, x + 62, y + 16], fill=alpha(SAFFRON_D, a))


def footer(draw, source, a=1.0):
    if not source or a <= 0.01:
        return
    draw.text((74, H - 48), "SOURCE", font=F(12, SEMI), fill=alpha(DIM, a))
    draw.text((74, H - 31), source, font=F(14, REG), fill=alpha(MUTED, a))


def progress_bar(draw, p, a=1.0):
    y = H - 7
    draw.rectangle([0, y, W, y + 4], fill=alpha((255, 255, 255), 0.05 * a))
    draw.rectangle([0, y, int(W * clamp(p)), y + 4], fill=alpha(SAFFRON, 0.85 * a))


def subtitle(draw, text, a=1.0):
    if not text or a <= 0.01:
        return
    f = F(24, REG)
    lines = wrap(draw, text, f, W - 320)
    lh = 33
    top = H - 62 - (len(lines) - 1) * lh
    for i, ln in enumerate(lines):
        y = top + i * lh
        x = (W - text_w(draw, ln, f)) / 2
        for ox, oy in ((0, 2), (0, -2), (2, 0), (-2, 0), (1, 1), (-1, -1)):
            draw.text((x + ox, y + oy), ln, font=f, fill=alpha((0, 0, 0), 0.6 * a))
        draw.text((x, y), ln, font=f, fill=alpha((255, 255, 255), a))


# ------------------------------------------------------------------ charts
def axes(draw, x0, y0, x1, y1):
    draw.line([(x0, y0), (x1, y0)], fill=alpha(DIM, 0.55), width=2)
    draw.line([(x0, y0), (x0, y1)], fill=alpha(DIM, 0.55), width=2)


def bar_chart(draw, rect, items, vmax, a=1.0, label_fmt="{:,.0f}",
              hi_index=None, bar_color=SAFFRON, top_color=SAFFRON_D,
              y_ticks=None):
    x0, y0, x1, y1 = rect
    n = max(1, len(items))
    axes(draw, x0, y0, x1, y1)
    if y_ticks:
        for tv in y_ticks:
            ty = y1 - (tv / vmax) * (y1 - y0)
            draw.line([(x0, ty), (x1, ty)], fill=alpha(DIM, 0.18), width=1)
            draw.text((x0 - 12, ty), f"{tv:g}", font=F(14, REG),
                      fill=alpha(DIM, a), anchor="rm")
    slot = (x1 - x0) / n
    bw = slot * 0.5
    for i, (lab, val) in enumerate(items):
        bx = x0 + slot * i + (slot - bw) / 2
        h = (val / vmax) * (y1 - y0)
        by = y1 - h
        c = top_color if (hi_index is not None and i == hi_index) else bar_color
        draw.rectangle([bx, by, bx + bw, y1], fill=alpha(c, 0.9 * a))
        draw.rectangle([bx, by, bx + bw, by + 4],
                       fill=alpha(mix(c, (255, 255, 255), .5), a))
        draw.text((bx + bw / 2, by - 25), label_fmt.format(val), font=F(17, SEMI),
                  fill=alpha(INK, a), anchor="mm")
        draw.text((bx + bw / 2, y1 + 12), lab, font=F(16, REG),
                  fill=alpha(MUTED, a), anchor="ma")


def hbar_panel(draw, rect, items, vmax, a=1.0, threshold=2.1,
               thr_color=GOLD, lab_w=170, highlight=()):
    x0, y0, x1, y1 = rect
    n = max(1, len(items))
    rh = (y1 - y0) / n
    track_x0 = x0 + lab_w
    track_w = (x1 - track_x0) - 58
    tx = track_x0 + (threshold / vmax) * track_w
    draw.line([(tx, y0 - 4), (tx, y1 + 2)], fill=alpha(thr_color, 0.7 * a), width=2)
    draw.text((tx, y0 - 18), "replacement 2.1", font=F(13, SEMI),
              fill=alpha(thr_color, 0.95 * a), anchor="mm")
    for i, (lab, val) in enumerate(items):
        cy = y0 + rh * i + rh / 2
        hot = lab in highlight
        draw.text((x0, cy), lab, font=F(15, SEMI if hot else REG),
                  fill=alpha(INK if hot else MUTED, a), anchor="lm")
        bh = min(18, rh * 0.55)
        draw.rectangle([track_x0, cy - bh / 2, track_x0 + track_w, cy + bh / 2],
                       fill=alpha((255, 255, 255), 0.05 * a))
        w = (val / vmax) * track_w
        c = RED if val > threshold else (TEAL if val < threshold else GOLD)
        draw.rectangle([track_x0, cy - bh / 2, track_x0 + w, cy + bh / 2],
                       fill=alpha(c, 0.92 * a))
        draw.text((track_x0 + w + 9, cy), f"{val:.1f}", font=F(14, SEMI),
                  fill=alpha(INK, a), anchor="lm")


def line_chart(draw, rect, series, vmin, vmax, a=1.0, color=SAFFRON,
               width=5, y_ticks=None, dash=False):
    x0, y0, x1, y1 = rect
    axes(draw, x0, y0, x1, y1)
    xs = [p[0] for p in series]
    xmin, xmax = min(xs), max(xs)

    def px(x):
        return x0 + (x - xmin) / (xmax - xmin) * (x1 - x0)

    def py(y):
        return y1 - (y - vmin) / (vmax - vmin) * (y1 - y0)

    if y_ticks:
        for tv in y_ticks:
            ty = py(tv)
            draw.line([(x0, ty), (x1, ty)], fill=alpha(DIM, 0.2), width=1)
            draw.text((x0 - 12, ty), f"{tv:g}", font=F(14, REG),
                      fill=alpha(DIM, a), anchor="rm")
    pts = [(px(x), py(y)) for x, y in series]
    if len(pts) > 1:
        if dash:
            for i in range(len(pts) - 1):
                if i % 2:
                    continue
                draw.line([pts[i], pts[i + 1]], fill=alpha(color, a), width=width)
        else:
            draw.line(pts, fill=alpha(color, a), width=width, joint="curve")
    return px, py


# ------------------------------------------------------------------ scenes
def sc_cold_open(c, draw):
    p = c.p
    a = ease_out(min(1, c.t / 1.0))
    val = 1.47 * ease_out(clamp((p - 0.06) / 0.34))
    draw.text((W / 2, 250), f"{val:.2f}", font=F(150, BOLD),
              fill=alpha(INK, a), anchor="mm")
    draw.text((W / 2, 342), "BILLION PEOPLE", font=F(34, SEMI),
              fill=alpha(SAFFRON, a), anchor="mm")
    draw.text((W / 2, 392), "live in India today", font=F(23, REG),
              fill=alpha(MUTED, a), anchor="mm")

    cols, rowsn, gap = 42, 5, 17
    gx0, gy0 = (W - (cols - 1) * gap) / 2, 450
    shown = ease_out(clamp((p - 0.20) / 0.30))
    total = cols * rowsn
    for i in range(total):
        if i / total > shown:
            break
        r, cc = divmod(i, cols)
        x, y = gx0 + cc * gap, gy0 + r * gap
        hot = (i * 7 % 6 == 0)
        rr = 4.2 if hot else 2.6
        draw.ellipse([x - rr, y - rr, x + rr, y + rr],
                     fill=alpha(SAFFRON if hot else (255, 255, 255),
                                (0.95 if hot else 0.28) * a))
    if p > 0.55:
        aa = ease_out(clamp((p - 0.55) / 0.2))
        draw.text((W / 2, gy0 + 3 * gap + 36),
                  "one in every six people alive on Earth is Indian",
                  font=F(20, REG), fill=alpha(MUTED, aa), anchor="mm")


def sc_independence(c, draw):
    p = c.p
    a = ease_out(min(1, c.t / 0.9))
    lx, rx = 250, W - 250
    draw.text((lx, 228), "1947", font=F(54, BOLD), fill=alpha(DIM, a), anchor="mm")
    draw.text((rx, 228), "2026", font=F(54, BOLD), fill=alpha(SAFFRON, a), anchor="mm")
    v47 = 389 * ease_out(clamp((p - 0.05) / 0.22))
    v26 = 1463 * ease_out(clamp((p - 0.22) / 0.26))
    draw.text((lx, 298), f"{v47:,.0f}M", font=F(40, BOLD), fill=alpha(INK, a), anchor="mm")
    draw.text((rx, 298), f"{v26:,.0f}M", font=F(40, BOLD), fill=alpha(INK, a), anchor="mm")
    draw.text((lx, 332), "population of independent India",
              font=F(14, REG), fill=alpha(MUTED, a), anchor="mm")
    draw.text((rx, 332), "population of India today",
              font=F(14, REG), fill=alpha(MUTED, a), anchor="mm")

    for x, v, col in ((lx, v47, DIM), (rx, v26, SAFFRON)):
        k = clamp((v / 1463) * 40)
        full = int(k)
        for i in range(full):
            r, c2 = divmod(i, 20)
            px_ = x - 150 + c2 * 15
            py_ = 410 + r * 15
            draw.ellipse([px_ - 4, py_ - 4, px_ + 4, py_ + 4], fill=alpha(col, 0.85 * a))

    ar = ease_out(clamp((p - 0.50) / 0.18))
    draw.text((W / 2, 424), "+", font=F(44, SEMI), fill=alpha(SAFFRON, ar), anchor="mm")
    draw.text((W / 2, 486), "1,074 MILLION PEOPLE ADDED",
              font=F(25, SEMI), fill=alpha(INK, ar), anchor="mm")
    draw.text((W / 2, 520), "in 79 years — on the same land",
              font=F(18, REG), fill=alpha(MUTED, ar), anchor="mm")
    bw = 640
    by = 566
    draw.rectangle([(W - bw) / 2, by, (W + bw) / 2, by + 10],
                   fill=alpha((255, 255, 255), 0.07 * ar))
    g = ease_out(clamp((p - 0.60) / 0.25))
    draw.rectangle([(W - bw) / 2, by, (W - bw) / 2 + bw * 0.276 * g, by + 10],
                   fill=alpha(SAFFRON, ar))
    draw.text((W / 2, by + 32), "3.76× the population of 1947",
              font=F(18, SEMI), fill=alpha(INK, ar), anchor="mm")


def sc_acceleration(c, draw):
    p = c.p
    a = ease_out(min(1, c.t / 0.8))
    items = [(str(y), v) for y, v in CENSUS]
    n_show = 1 + int(clamp((p - 0.10) / 0.60) * (len(items) - 1))
    bar_chart(draw, (110, 250, W - 90, 556), items[:n_show], 1300, a,
              label_fmt="{:,.0f}M", hi_index=n_show - 1, y_ticks=[0, 400, 800, 1200])
    if p > 0.35:
        aa = ease_out(clamp((p - 0.35) / 0.15))
        draw.text((110, 588), "Population at each decennial census (millions)",
                  font=F(17, REG), fill=alpha(MUTED, aa))
        draw.text((W - 90, 588), "each decade added more than the last",
                  font=F(17, SEMI), fill=alpha(SAFFRON, aa), anchor="ra")
    if p > 0.86:
        aa = ease_out(clamp((p - 0.86) / 0.1))
        draw.text((110, 618), "then, in the 2000s, the gain fell by 62 million",
                  font=F(17, REG), fill=alpha(MUTED, aa))


def sc_census(c, draw):
    p = c.p
    a = ease_out(min(1, c.t / 0.8))
    labels = ["51-61", "61-71", "71-81", "81-91", "91-01", "01-11"]
    n_show = 1 + int(clamp((p - 0.08) / 0.52) * (len(labels) - 1))
    draw.text((120, 246), "People added per decade (millions)", font=F(18, SEMI),
              fill=alpha(INK, a))
    bar_chart(draw, (120, 300, W - 110, 540), list(zip(labels, DECADE_DELTA))[:n_show],
              220, a, label_fmt="+{:.0f}M", hi_index=n_show - 1,
              bar_color=TEAL, top_color=SAFFRON, y_ticks=[0, 100, 200])
    if p > 0.62:
        aa = ease_out(clamp((p - 0.62) / 0.14))
        draw.text((120, 584), "the biggest jump of any decade: +200M (1991→2001)",
                  font=F(19, SEMI), fill=alpha(SAFFRON, aa))
    if p > 0.80:
        aa = ease_out(clamp((p - 0.80) / 0.12))
        draw.text((120, 616), "the 2021 census is still being released in phases",
                  font=F(17, REG), fill=alpha(MUTED, aa))


def sc_fertility(c, draw):
    p = c.p
    a = ease_out(min(1, c.t / 0.8))
    rect = (120, 236, W - 90, 536)
    vmin, vmax = 1.0, 6.5
    n = 1 + int(clamp((p - 0.08) / 0.42) * (len(TFR) - 1))
    shown = TFR[:n]
    draw.text((120, 196), "Total fertility rate (children per woman)",
              font=F(18, SEMI), fill=alpha(INK, a))
    if len(shown) > 1:
        line_chart(draw, rect, shown, vmin, vmax, a, color=SAFFRON,
                   width=5, y_ticks=[1, 2, 3, 4, 5, 6])
    else:
        axes(draw, *rect)

    show_line = p > 0.46
    if show_line:
        aa = ease_out(clamp((p - 0.46) / 0.12))
        ry = rect[3] - (REPLACEMENT - vmin) / (vmax - vmin) * (rect[3] - rect[1])
        draw.line([(rect[0], ry), (rect[2], ry)], fill=alpha(TEAL, 0.75 * aa), width=2)
        draw.text((rect[0] + 8, ry - 13), "replacement level 2.1", font=F(15, SEMI),
                  fill=alpha(TEAL, aa), anchor="lm")

    for i, (yr, v) in enumerate(TFR):
        if i >= n:
            break
        px_ = rect[0] + i / (len(TFR) - 1) * (rect[2] - rect[0])
        py_ = rect[3] - (v - vmin) / (vmax - vmin) * (rect[3] - rect[1])
        draw.ellipse([px_ - 7, py_ - 7, px_ + 7, py_ + 7], fill=alpha(SAFFRON, a))
        draw.text((px_, py_ + 22), f"{v:.1f}", font=F(18, SEMI),
                  fill=alpha(INK, a), anchor="mm")
        draw.text((px_, rect[3] + 14), str(yr), font=F(15, REG),
                  fill=alpha(MUTED, a), anchor="ma")
    if p > 0.72:
        aa = ease_out(clamp((p - 0.72) / 0.14))
        draw.text((120, 580),
                  "India is now below replacement — yet the population kept growing",
                  font=F(19, SEMI), fill=alpha(SAFFRON, aa))
    if p > 0.86:
        aa = ease_out(clamp((p - 0.86) / 0.1))
        draw.text((120, 612),
                  "the reason: momentum, and a very young age structure",
                  font=F(17, REG), fill=alpha(MUTED, aa))


def sc_states(c, draw):
    p = c.p
    a = ease_out(min(1, c.t / 0.8))
    ordered = sorted(STATE_TFR_NFHS5.items(), key=lambda kv: -kv[1])
    half = (len(ordered) + 1) // 2
    idx = {name: i for i, (name, _) in enumerate(ordered)}
    n_show = 1 + int(clamp((p - 0.08) / 0.80) * (len(ordered) - 1))
    left = [(n, v) for n, v in ordered[:half] if idx[n] < n_show]
    right = [(n, v) for n, v in ordered[half:] if idx[n] < n_show]
    hi = ("Bihar", "Goa")
    if left:
        hbar_panel(draw, (64, 252, 632, 600), left, 3.2, a, threshold=2.1,
                   lab_w=165, highlight=hi)
    if right:
        hbar_panel(draw, (676, 252, 1244, 600), right, 3.2, a, threshold=2.1,
                   lab_w=165, highlight=hi)
    draw.text((64, 200), "STILL ABOVE REPLACEMENT", font=F(15, SEMI),
              fill=alpha(RED, a))
    draw.text((676, 200), "AT OR BELOW REPLACEMENT", font=F(15, SEMI),
              fill=alpha(TEAL, a))


def sc_momentum(c, draw):
    p = c.p
    a = ease_out(min(1, c.t / 0.8))
    unit, base_y, factor = 18, 588, 2.3
    for cx, im, iff, lab, col, sub in (
            (390, 2, 3, "2026", SAFFRON, "a wide base"),
            (890, 4, 5, "2061", BLUE, "a narrower base, a wider top")):
        draw.text((cx, 186), lab, font=F(24, SEMI), fill=alpha(col, a), anchor="mm")
        draw.text((cx, 212), sub, font=F(14, REG), fill=alpha(MUTED, a), anchor="mm")
        for i, row in enumerate(PYRAMID):
            y = base_y - i * unit
            for val in (row[im], row[iff]):
                w = val * unit * factor
                draw.rectangle([cx - w, y - unit * 0.40, cx, y + unit * 0.40],
                               fill=alpha(col, 0.85 * a))
                draw.rectangle([cx, y - unit * 0.40, cx + w, y + unit * 0.40],
                               fill=alpha(col, 0.85 * a))
    for i, row in enumerate(PYRAMID):
        y = base_y - i * unit
        draw.text((186, y), f"{row[0]}", font=F(11, REG),
                  fill=alpha(DIM, a * 0.9), anchor="rm")
    draw.text((186, 618), "age", font=F(12, REG), fill=alpha(DIM, a), anchor="rm")
    draw.text((390, base_y + 18), "men", font=F(14, SEMI), fill=alpha(MUTED, a), anchor="mm")
    draw.text((890, base_y + 18), "women", font=F(14, SEMI), fill=alpha(MUTED, a), anchor="mm")

    # middle annotation
    draw.text((640, 268), "median age", font=F(15, REG), fill=alpha(MUTED, a), anchor="mm")
    draw.text((640, 308), "29", font=F(38, BOLD), fill=alpha(SAFFRON, a), anchor="mm")
    draw.text((640, 350), "→ 38", font=F(30, SEMI), fill=alpha(BLUE, a), anchor="mm")
    draw.text((640, 388), "by 2061", font=F(15, REG), fill=alpha(MUTED, a), anchor="mm")
    if p > 0.62:
        aa = ease_out(clamp((p - 0.62) / 0.16))
        draw.text((640, 452), "the base narrows slowly —", font=F(16, REG),
                  fill=alpha(INK, aa), anchor="mm")
        draw.text((640, 476), "the top widens fast", font=F(16, REG),
                  fill=alpha(INK, aa), anchor="mm")
    if p > 0.80:
        aa = ease_out(clamp((p - 0.80) / 0.12))
        draw.text((640, 560), "45% of Indians are under 25",
                  font=F(17, SEMI), fill=alpha(SAFFRON, aa), anchor="mm")


def sc_dividend(c, draw):
    p = c.p
    a = ease_out(min(1, c.t / 0.8))
    val = 1500 * ease_out(clamp((p - 0.08) / 0.30))
    draw.text((W / 2, 326), f"{val:,.0f}M", font=F(104, BOLD),
              fill=alpha(INK, a), anchor="mm")
    draw.text((W / 2, 400), "PEOPLE OF WORKING AGE", font=F(28, SEMI),
              fill=alpha(SAFFRON, a), anchor="mm")
    draw.text((W / 2, 440), "the largest workforce on Earth", font=F(20, REG),
              fill=alpha(MUTED, a), anchor="mm")
    if p > 0.45:
        aa = ease_out(clamp((p - 0.45) / 0.15))
        bw = 700
        bx = (W - bw) / 2
        by = 518
        draw.rectangle([bx, by, bx + bw, by + 16], fill=alpha((255, 255, 255), 0.07 * aa))
        g = ease_out(clamp((p - 0.50) / 0.20))
        draw.rectangle([bx, by, bx + bw * 0.32 * g, by + 16], fill=alpha(TEAL, aa))
        draw.text((bx, by + 30),
                  "dependency ratio — near its lowest point in decades",
                  font=F(16, REG), fill=alpha(MUTED, aa))


def sc_challenges(c, draw):
    p = c.p
    a = ease_out(min(1, c.t / 0.8))
    lx, rx = 320, 890
    val = 7.8 * ease_out(clamp((p - 0.08) / 0.24))
    draw.text((lx, 282), f"{val:.1f}M", font=F(88, BOLD), fill=alpha(SAFFRON, a), anchor="mm")
    draw.text((lx, 344), "NEW JOBS", font=F(26, SEMI), fill=alpha(INK, a), anchor="mm")
    draw.text((lx, 380), "needed every month", font=F(19, REG), fill=alpha(MUTED, a), anchor="mm")
    draw.text((lx, 412), "just to absorb new entrants", font=F(16, REG),
              fill=alpha(DIM, a), anchor="mm")

    if p > 0.46:
        aa = ease_out(clamp((p - 0.46) / 0.16))
        v2 = 46 * ease_out(clamp((p - 0.55) / 0.25))
        draw.text((rx, 282), f"{v2:.0f}%", font=F(76, BOLD), fill=alpha(TEAL, aa), anchor="mm")
        draw.text((rx, 336), "URBAN BY 2036", font=F(22, SEMI), fill=alpha(INK, aa), anchor="mm")
        draw.text((rx, 368), "from 36% today", font=F(18, REG), fill=alpha(MUTED, aa), anchor="mm")
        bw = 300
        by = 400
        draw.rectangle([rx - bw / 2, by, rx + bw / 2, by + 14],
                       fill=alpha((255, 255, 255), 0.07 * aa))
        draw.rectangle([rx - bw / 2, by, rx - bw / 2 + bw * v2 / 100, by + 14],
                       fill=alpha(TEAL, aa))
        draw.text((rx, by + 48), "+600 MILLION more city dwellers",
                  font=F(17, SEMI), fill=alpha(INK, aa), anchor="mm")
        draw.text((rx, by + 76), "≈ 1 million people absorbed per day",
                  font=F(16, REG), fill=alpha(MUTED, aa), anchor="mm")
    draw.line([(640, 236), (640, 556)], fill=alpha(DIM, 0.3 * a), width=2)
    if p > 0.82:
        aa = ease_out(clamp((p - 0.82) / 0.12))
        draw.text((W / 2, 600), "the planning challenge of the next thirty years",
                  font=F(19, SEMI), fill=alpha(SAFFRON, aa), anchor="mm")


def sc_path(c, draw):
    p = c.p
    a = ease_out(min(1, c.t / 0.8))
    rect = (110, 236, W - 90, 566)
    vmin, vmax = 300.0, 1800.0
    years = [y for y, _ in TRAJECTORY]
    span = max(years) - min(years)
    n = 1 + int(clamp((p - 0.06) / 0.44) * (len(TRAJECTORY) - 1))
    shown = TRAJECTORY[:n]
    draw.text((110, 196), "Population, 1947-2100 (millions) — UN medium variant",
              font=F(17, SEMI), fill=alpha(INK, a))
    line_chart(draw, rect, TRAJECTORY, vmin, vmax, a * 0.15, color=MUTED,
               width=3, dash=True)
    if len(shown) > 1:
        line_chart(draw, rect, shown, vmin, vmax, a, color=SAFFRON, width=6)
    else:
        axes(draw, *rect)
    if p > 0.48:
        aa = ease_out(clamp((p - 0.48) / 0.14))
        py_ = rect[3] - (POP_PEAK - vmin) / (vmax - vmin) * (rect[3] - rect[1])
        px_ = rect[0] + (POP_PEAK_YEAR - min(years)) / span * (rect[2] - rect[0])
        draw.ellipse([px_ - 9, py_ - 9, px_ + 9, py_ + 9], fill=alpha(GOLD, aa))
        draw.text((px_, py_ - 26), "peak 1.70B", font=F(17, SEMI),
                  fill=alpha(GOLD, aa), anchor="mm")
    for i, (y, v) in enumerate(TRAJECTORY):
        if i >= n:
            break
        px_ = rect[0] + (y - min(years)) / span * (rect[2] - rect[0])
        py_ = rect[3] - (v - vmin) / (vmax - vmin) * (rect[3] - rect[1])
        draw.ellipse([px_ - 6, py_ - 6, px_ + 6, py_ + 6], fill=alpha(SAFFRON, a))
    for y in (1950, 2000, 2050, 2100):
        px_ = rect[0] + (y - min(years)) / span * (rect[2] - rect[0])
        draw.text((px_, rect[3] + 14), str(y), font=F(15, REG),
                  fill=alpha(MUTED, a), anchor="ma")
    for v in (500, 1000, 1500):
        py_ = rect[3] - (v - vmin) / (vmax - vmin) * (rect[3] - rect[1])
        draw.line([(rect[0], py_), (rect[2], py_)], fill=alpha(DIM, 0.16 * a), width=1)
        draw.text((rect[0] - 12, py_), f"{v:,}", font=F(14, REG),
                  fill=alpha(DIM, a), anchor="rm")
    if p > 0.66:
        aa = ease_out(clamp((p - 0.66) / 0.14))
        draw.text((110, 606),
                  "growth slows → peaks early 2060s → declines for the first time since independence",
                  font=F(17, REG), fill=alpha(MUTED, aa))


def sc_close(c, draw):
    p = c.p
    a = ease_out(min(1, c.t / 0.8))
    boxes = [("GROWTH, SLOWING",
              ["Fertility already at replacement",
               "Peak in the early 2060s",
               "A plateau that could last a century"], TEAL),
             ("SCALE, NOT SLOWING",
              ["1.5 billion people",
               "Housed, fed, employed, moved",
               "Every single day"], SAFFRON)]
    for i, (title, body, col) in enumerate(boxes):
        x = 110 + i * 560
        aa = ease_out(clamp((p - 0.06 - i * 0.12) / 0.18))
        y = 252
        draw.rounded_rectangle([x, y, x + 500, y + 236], radius=14,
                               fill=alpha((255, 255, 255), 0.045 * aa),
                               outline=alpha(col, 0.55 * aa), width=2)
        draw.text((x + 30, y + 32), title, font=F(21, SEMI), fill=alpha(col, aa))
        draw_lines(draw, body, (x + 30, y + 90), F(18, REG),
                   alpha(INK, aa * 0.92), spacing=12)
    if p > 0.52:
        aa = ease_out(clamp((p - 0.52) / 0.16))
        draw.text((W / 2, 542),
                  "The dividend and the burden are the same fact, seen from two ends.",
                  font=F(23, SEMI), fill=alpha(INK, aa), anchor="mm")
    if p > 0.74:
        aa = ease_out(clamp((p - 0.74) / 0.14))
        draw.text((W / 2, 596),
                  "The next 25 years will determine the century for a fifth of humanity.",
                  font=F(19, REG), fill=alpha(SAFFRON, aa), anchor="mm")


def sc_outro(c, draw):
    p = c.p
    a = ease_out(min(1, t0 := c.t / 0.9))
    for i, (big, lab) in enumerate(OUTRO):
        x = 105 + i * 275
        aa = ease_out(clamp((p - 0.06 - i * 0.10) / 0.16))
        y = 276
        draw.rounded_rectangle([x, y, x + 245, y + 152], radius=12,
                               fill=alpha((255, 255, 255), 0.045 * aa),
                               outline=alpha(SAFFRON_D, 0.4 * aa), width=2)
        draw.text((x + 122, y + 60), big, font=F(44, BOLD), fill=alpha(SAFFRON, aa), anchor="mm")
        lines = wrap(draw, lab, F(15, REG), 205)
        draw_lines(draw, lines, (x + 122, y + 100), F(15, REG),
                   alpha(MUTED, aa), anchor="ma", spacing=5)
    if p > 0.42:
        aa = ease_out(clamp((p - 0.42) / 0.16))
        draw.text((W / 2, 486), "POPULATION RISING", font=F(46, BOLD),
                  fill=alpha(INK, aa), anchor="mm")
        draw.text((W / 2, 532), "India's Demographic Decade", font=F(24, REG),
                  fill=alpha(MUTED, aa), anchor="mm")
        draw.text((W / 2, 592), CREDITS, font=F(11, REG), fill=alpha(DIM, aa), anchor="mm")


SCENE_FNS = {
    "cold_open": sc_cold_open,
    "independence": sc_independence,
    "acceleration": sc_acceleration,
    "census": sc_census,
    "fertility": sc_fertility,
    "states": sc_states,
    "momentum": sc_momentum,
    "dividend": sc_dividend,
    "challenges": sc_challenges,
    "path": sc_path,
    "close": sc_close,
    "outro": sc_outro,
}


class Ctx:
    """Per-frame context: which sentence is speaking, and how far into it."""

    def __init__(self, scene, t):
        self.t = t
        self.dur = scene["duration"]
        self.sent = scene["sentences"]
        n = max(1, len(self.sent))
        self.beat = 0
        self.bp = 0.0
        for i, s in enumerate(self.sent):
            if t >= s["start"] and t < s["start"] + s["dur"]:
                self.beat = i
                self.bp = clamp((t - s["start"]) / max(s["dur"], 1e-6))
                break
        else:
            # before the first or after the last sentence
            if self.sent and t >= self.sent[-1]["start"] + self.sent[-1]["dur"]:
                self.beat = len(self.sent) - 1
                self.bp = 1.0
        # scene-level progress through the spoken part, 0..1
        speech_start = self.sent[0]["start"] if self.sent else 0.0
        speech_end = (self.sent[-1]["start"] + self.sent[-1]["dur"]) if self.sent else 1.0
        span = max(1e-6, speech_end - speech_start)
        self.p = clamp((t - speech_start) / span)
        self.cue = None
        for s in self.sent:
            if s["start"] <= t <= s["start"] + s["dur"] + 0.30:
                self.cue = s["text"]


TOTAL = 1.0


def render_scene(scene, outdir, index, start_frame):
    fn = SCENE_FNS[scene["id"]]
    n_frames = int(math.ceil(scene["duration"] * FPS))
    gf = start_frame
    for i in range(n_frames):
        t = i / FPS
        img = bg_gradient(t + index * 3.7)
        draw = ImageDraw.Draw(img)
        c = Ctx(scene, t)
        ha = ease_out(clamp(t / 0.9))
        header(draw, scene.get("kicker", ""), scene.get("title", ""), ha)
        fn(c, draw)
        footer(draw, scene.get("source", ""), ease_out(clamp((t - 0.5) / 0.8)))
        subtitle(draw, c.cue, ease_out(clamp((t - 0.2) / 0.4)))
        progress_bar(draw, (scene["start"] + t) / TOTAL, 1.0)
        img.save(os.path.join(outdir, f"f{gf:05d}.png"), compress_level=1)
        gf += 1
    return n_frames


def main():
    with open(sys.argv[1], encoding="utf-8") as fh:
        tl = json.load(fh)
    outdir = sys.argv[2]
    os.makedirs(outdir, exist_ok=True)
    global TOTAL
    TOTAL = tl["total"]
    gf = 0
    for i, sc in enumerate(tl["scenes"]):
        n = render_scene(sc, outdir, i, gf)
        gf += n
        print(f"scene {i:02d} {sc['id']:<16} {n:4d} frames  {sc['duration']:.2f}s", flush=True)
    print(f"TOTAL_FRAMES {gf}", flush=True)


if __name__ == "__main__":
    main()
