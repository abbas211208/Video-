# POPULATION RISING
### India's Demographic Decade

A documentary short on India's population growth — what it was, why it
happened, where it is going, and what it requires.

*Sources: UN World Population Prospects 2024 • Census of India 1951-2011 • Sample Registration System • NFHS-5 (2019-21) • Economic Survey 2023-24*

---

## 1. 1.47 BILLION
*On screen: INDIA, RIGHT NOW*

Here is a number that is difficult to hold in the mind.

One point four seven billion people.

That is not a projection for the year twenty fifty, and it is not a target.

That is an estimate of how many people are living in India at this moment.

More than one in every six human beings alive on this planet is Indian.

By sheer head count, this is now the largest country on Earth.

> On-screen source: UN World Population Prospects 2024 (mid-year estimate)

---

## 2. FROM 389 MILLION TO 1.47 BILLION
*On screen: 1947 - 2026*

To feel what that means, start with independence.

On the fifteenth of August, nineteen forty-seven, a divided India became one, with roughly three hundred and eighty-nine million people.

In the seventy-nine years since, the country has added more than one billion people.

It is not that Indians have become more numerous than they were.

It is that the same country, on the same land, is now home to nearly four times as many people.

> On-screen source: Census of India • UN World Population Prospects 2024

---

## 3. THE GREAT ACCELERATION
*On screen: DECADE BY DECADE*

The growth did not arrive at a steady pace. It surged.

The census of nineteen fifty-one counted three hundred and fifty-three million people.

By nineteen eighty-one there were seven hundred and ten million.

By two thousand and one, one point zero seven billion.

The Green Revolution of the nineteen sixties and seventies lifted harvests, erased famine, and cut infant death rates.

Each decade added more people than the one before it.

The curve was not a straight line. It was a hockey stick.

And the first sign of the turn came in the two thousands, when a single decade's gain fell by sixty-two million.

> On-screen source: Census of India 1951-2011

---

## 4. THE RECORD IN THE CENSUS
*On screen: 1951 - 2011*

The census is unforgiving about scale.

Nineteen fifty-one, three hundred and fifty-three million.

Nineteen seventy-one, five hundred and fifty-six million.

Nineteen ninety-one, eight hundred and seventy-four million.

Two thousand and eleven, one point two one billion.

That single decade added a hundred and thirty-seven million people.

But the largest gain of any decade was actually two hundred million, between nineteen ninety-one and two thousand and one.

The twenty twenty-one census, delayed first by the pandemic and then by data checks, is still being released in phases.

The direction is not in doubt. The magnitude is.

> On-screen source: Census of India 1951-2011

---

## 5. THE ENGINE HAS SLOWED
*On screen: TOTAL FERTILITY RATE*

And yet the real story of the last thirty years is that the engine of growth has cooled.

The total fertility rate, the average number of children a woman has, fell from about five point nine in nineteen seventy-one to about two point zero today.

That is below the two point one replacement level.

On every other continent, that is where the story ends.

In India, it is not.

Because the population kept growing anyway, for two reasons: demographic momentum, and a young age structure.

> On-screen source: Sample Registration System • NFHS-5

---

## 6. TWO INDIA'S, ONE MAP
*On screen: TFR BY STATE, NFHS-5 (2019-21)*

Nationally the transition looks smooth. State by state, it does not.

In Bihar, the family survey records about three children per woman, a level India passed through in the nineteen seventies.

In Goa, the same survey records one point one.

In Kerala, Tamil Nadu and Andhra Pradesh, fertility sits at or below replacement, and in some districts the population is already shrinking without migration.

India is now two demographic countries sharing one flag, one constitution, and one labour market.

> On-screen source: National Family Health Survey, NFHS-5 (2019-21)

---

## 7. MOMENTUM
*On screen: THE PYRAMID IS THE RESERVOIR*

This is why.

A population keeps growing after fertility falls, because the number of people entering childbearing ages was set decades earlier.

India's median age is about twenty-nine, and roughly forty-five percent of Indians are under twenty-five.

The base of the pyramid is not narrowing as fast as the top is ageing.

For the next twenty years, the number of Indians in their twenties and thirties will grow by millions every year, even where births are fewer than deaths.

> On-screen source: UN World Population Prospects 2024 (projections)

---

## 8. THE DEMOGRAPHIC DIVIDEND
*On screen: AND THE DIVIDEND ARISING*

The same fact that makes the population hard to sustain makes it valuable.

For the next twenty-five years, India will have the largest workforce on Earth.

The dependency ratio, the share of people too young or too old to work, is close to its lowest point in decades.

If India can productively employ its working age population, this is a once-in-a-century economic opening.

The prize is not theoretical. It is roughly one and a half billion workers.

> On-screen source: UN World Population Prospects 2024 • Economic Survey 2023-24

---

## 9. THE BILL ARRIVES
*On screen: JOBS, CITIES, WATER*

And the bill arrives at the same time.

The Economic Survey estimates India must create about seventy-eight lakh, that is nearly eight million, new jobs every single month, just to absorb new entrants.

Urbanisation is accelerating: about thirty-six percent of Indians live in cities today.

By twenty thirty-six, roughly six hundred million more people will live in Indian cities.

Every one of them needs water, power, housing, sanitation, and a commute.

Cities must absorb the equivalent of a million people every day.

That is the planning challenge of the next thirty years.

> On-screen source: Economic Survey 2023-24 • UN-Habitat • World Bank

---

## 10. THE ROAD TO 1.7 BILLION
*On screen: UN PROJECTION TO 2061*

Where does it end?

The United Nations projects India's population passing one point six seven billion around twenty fifty.

It peaks at about one point seven billion in the early twenty sixties, and then, for the first time since independence, slowly declines.

China peaked in twenty twenty-one. India follows roughly forty years behind.

By twenty one hundred, India is projected back near one point five billion, still the largest country in the world, and still home to one in five people alive.

> On-screen source: UN World Population Prospects 2024 (medium variant projection)

---

## 11. WHAT THE NUMBER REQUIRES
*On screen: CLOSING*

So the story of India's population is really two stories running at once.

A growth story that is slowing: fertility at replacement, a peak within forty years, and a plateau that could last a century.

And a scale story that is not slowing at all.

One and a half billion people who must be housed, fed, employed and moved every single day.

The demographic dividend and the demographic burden are the same fact seen from two ends.

What India does with the next twenty-five years of that fact will determine the century for a fifth of humanity.

---

## Outro

Population rising. India's demographic decade. One point four seven billion today, one point seven billion by the early twenty sixties, and one point five billion by the end of the century. The dividend and the burden are the same fact. What India does with the next twenty-five years will determine the century.

---
