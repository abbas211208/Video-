"""
Content + narration for "Population Rising: India's Demographic Decade".

Narration is stored sentence-by-sentence so that each sentence becomes
(a) one TTS unit, (b) one subtitle cue, and (c) a timing anchor for the
on-screen animation.

Sources used throughout (shown on screen):
  UN World Population Prospects 2024 revision
  Census of India 1951-2011
  Sample Registration System (SRS) statistical reports
  NFHS-5, 2019-21 (state fertility)
  Economic Survey 2023-24 (employment)
  UN-Habitat / World Bank (urbanisation)
"""

TITLE = "POPULATION RISING"
SUBTITLE = "India's Demographic Decade"
CREDITS = ("Sources: UN World Population Prospects 2024  •  Census of India 1951-2011  •  "
           "Sample Registration System  •  NFHS-5 (2019-21)  •  Economic Survey 2023-24")

# ---------------------------------------------------------------- data

CENSUS = [
    (1951, 352.7), (1961, 439.0), (1971, 556.4), (1981, 710.0),
    (1991, 873.8), (2001, 1073.4), (2011, 1210.9),
]
DECADE_DELTA = [86, 117, 154, 164, 200, 137]   # millions added, 1951->2011

POP_1947 = 389.0      # millions, year of independence
POP_2026 = 1463.0     # millions, UN WPP 2024 mid-year estimate
POP_2050 = 1670.0     # millions
POP_PEAK = 1701.0     # millions
POP_PEAK_YEAR = 2061
POP_2100 = 1505.0     # millions

# Smooth trajectory used for the animated growth curve (millions)
TRAJECTORY = [
    (1947, 389.0), (1961, 439.0), (1971, 556.4), (1981, 710.0), (1991, 873.8),
    (2001, 1073.4), (2011, 1210.9), (2026, 1463.0), (2035, 1560.0),
    (2050, 1670.0), (2061, 1701.0), (2075, 1660.0), (2100, 1505.0),
]

TFR = [
    (1971, 5.9), (1981, 4.9), (1991, 3.7), (2001, 2.8), (2011, 2.4),
    (2021, 2.0), (2024, 1.9),
]
REPLACEMENT = 2.1

STATE_TFR = [
    ("Bihar", 3.0), ("Meghalaya", 2.9), ("Uttar Pradesh", 2.4), ("Rajasthan", 2.4),
    ("Jharkhand", 2.3), ("Madhya Pradesh", 2.3), ("Mizoram", 2.3), ("Manipur", 2.2),
    ("Assam", 2.1), ("Chhattisgarh", 2.0), ("Gujarat", 1.9), ("Haryana", 1.9),
    ("Uttarakhand", 1.8), ("Maharashtra", 1.7), ("Himachal Pradesh", 1.7),
    ("Karnataka", 1.6), ("Kerala", 1.6), ("Tamil Nadu", 1.6), ("Punjab", 1.6),
    ("Odisha", 1.6), ("Andhra Pradesh", 1.5), ("West Bengal", 1.4), ("Delhi", 1.4),
    ("Goa", 1.1),
]
STATE_TFR_NFHS5 = {
    "Bihar": 3.0, "Meghalaya": 2.9, "Uttar Pradesh": 2.4, "Rajasthan": 2.4,
    "Jharkhand": 2.3, "Madhya Pradesh": 2.3, "Mizoram": 2.3, "Manipur": 2.2,
    "Assam": 2.1, "Chhattisgarh": 2.0, "Gujarat": 1.9, "Haryana": 1.9,
    "Uttarakhand": 1.8, "Maharashtra": 1.7, "Himachal Pradesh": 1.7,
    "Karnataka": 1.6, "Kerala": 1.6, "Tamil Nadu": 1.6, "Punjab": 1.6,
    "Odisha": 1.6, "Andhra Pradesh": 1.5, "West Bengal": 1.4, "Delhi": 1.4,
    "Goa": 1.1,
}

# Stylised population pyramid (% of population), 2026 vs projected 2061
PYRAMID = [
    # (age_low, age_high, pct_2026_m, pct_2026_f, pct_2061_m, pct_2061_f)
    (0, 4, 3.9, 3.8, 2.9, 2.8),
    (5, 9, 4.1, 3.9, 3.0, 2.9),
    (10, 14, 4.3, 4.1, 3.2, 3.1),
    (15, 19, 4.2, 4.0, 3.4, 3.3),
    (20, 24, 4.0, 3.9, 3.6, 3.5),
    (25, 29, 3.8, 3.8, 3.7, 3.7),
    (30, 34, 3.6, 3.7, 3.7, 3.7),
    (35, 39, 3.3, 3.5, 3.6, 3.6),
    (40, 44, 2.9, 3.2, 3.4, 3.5),
    (45, 49, 2.4, 2.8, 3.1, 3.3),
    (50, 54, 2.0, 2.5, 2.8, 3.1),
    (55, 59, 1.7, 2.2, 2.4, 2.8),
    (60, 64, 1.3, 1.8, 2.0, 2.5),
    (65, 69, 0.9, 1.4, 1.6, 2.2),
    (70, 74, 0.6, 1.0, 1.2, 1.8),
    (75, 79, 0.4, 0.6, 0.8, 1.4),
    (80, 100, 0.4, 0.7, 0.9, 1.9),
]

# Approximate city markers: (name, lon, lat, population in millions, 2026)
CITIES = [
    ("Delhi", 77.21, 28.61, 34.0), ("Mumbai", 72.88, 19.08, 22.0),
    ("Kolkata", 88.36, 22.57, 16.0), ("Bengaluru", 77.59, 12.97, 14.0),
    ("Chennai", 80.27, 13.08, 12.5), ("Hyderabad", 78.49, 17.39, 11.0),
    ("Ahmedabad", 72.57, 23.02, 9.0), ("Pune", 73.86, 18.52, 8.0),
    ("Surat", 72.83, 21.17, 7.5), ("Jaipur", 75.79, 26.91, 4.5),
    ("Lucknow", 80.95, 26.85, 4.0), ("Kanpur", 80.35, 26.45, 3.5),
    ("Nagpur", 79.09, 21.15, 3.2), ("Patna", 85.14, 25.59, 3.0),
    ("Bhopal", 77.41, 23.26, 3.0), ("Varanasi", 83.01, 25.32, 2.6),
    ("Guwahati", 91.75, 26.14, 1.6), ("Chandigarh", 76.78, 30.73, 1.6),
    ("Ranchi", 85.31, 23.34, 1.5), ("Thiruvananthapuram", 76.95, 8.49, 1.5),
]

# ---------------------------------------------------------------- narration
# "sentences" is a list of strings; each becomes one TTS clip + one subtitle cue.

SCENES = [
    dict(
        id="cold_open",
        title="1.47 BILLION",
        kicker="INDIA, RIGHT NOW",
        source="UN World Population Prospects 2024 (mid-year estimate)",
        sentences=[
            "Here is a number that is difficult to hold in the mind.",
            "One point four seven billion people.",
            "That is not a projection for the year twenty fifty, and it is not a target.",
            "That is an estimate of how many people are living in India at this moment.",
            "More than one in every six human beings alive on this planet is Indian.",
            "By sheer head count, this is now the largest country on Earth.",
        ],
    ),
    dict(
        id="independence",
        title="FROM 389 MILLION TO 1.47 BILLION",
        kicker="1947 - 2026",
        source="Census of India  •  UN World Population Prospects 2024",
        sentences=[
            "To feel what that means, start with independence.",
            "On the fifteenth of August, nineteen forty-seven, a divided India became one, with roughly three hundred and eighty-nine million people.",
            "In the seventy-nine years since, the country has added more than one billion people.",
            "It is not that Indians have become more numerous than they were.",
            "It is that the same country, on the same land, is now home to nearly four times as many people.",
        ],
    ),
    dict(
        id="acceleration",
        title="THE GREAT ACCELERATION",
        kicker="DECADE BY DECADE",
        source="Census of India 1951-2011",
        sentences=[
            "The growth did not arrive at a steady pace. It surged.",
            "The census of nineteen fifty-one counted three hundred and fifty-three million people.",
            "By nineteen eighty-one there were seven hundred and ten million.",
            "By two thousand and one, one point zero seven billion.",
            "The Green Revolution of the nineteen sixties and seventies lifted harvests, erased famine, and cut infant death rates.",
            "Each decade added more people than the one before it.",
            "The curve was not a straight line. It was a hockey stick.",
            "And the first sign of the turn came in the two thousands, when a single decade's gain fell by sixty-two million.",
        ],
    ),
    dict(
        id="census",
        title="THE RECORD IN THE CENSUS",
        kicker="1951 - 2011",
        source="Census of India 1951-2011",
        sentences=[
            "The census is unforgiving about scale.",
            "Nineteen fifty-one, three hundred and fifty-three million.",
            "Nineteen seventy-one, five hundred and fifty-six million.",
            "Nineteen ninety-one, eight hundred and seventy-four million.",
            "Two thousand and eleven, one point two one billion.",
            "That single decade added a hundred and thirty-seven million people.",
            "But the largest gain of any decade was actually two hundred million, between nineteen ninety-one and two thousand and one.",
            "The twenty twenty-one census, delayed first by the pandemic and then by data checks, is still being released in phases.",
            "The direction is not in doubt. The magnitude is.",
        ],
    ),
    dict(
        id="fertility",
        title="THE ENGINE HAS SLOWED",
        kicker="TOTAL FERTILITY RATE",
        source="Sample Registration System  •  NFHS-5",
        sentences=[
            "And yet the real story of the last thirty years is that the engine of growth has cooled.",
            "The total fertility rate, the average number of children a woman has, fell from about five point nine in nineteen seventy-one to about two point zero today.",
            "That is below the two point one replacement level.",
            "On every other continent, that is where the story ends.",
            "In India, it is not.",
            "Because the population kept growing anyway, for two reasons: demographic momentum, and a young age structure.",
        ],
    ),
    dict(
        id="states",
        title="TWO INDIA'S, ONE MAP",
        kicker="TFR BY STATE, NFHS-5 (2019-21)",
        source="National Family Health Survey, NFHS-5 (2019-21)",
        sentences=[
            "Nationally the transition looks smooth. State by state, it does not.",
            "In Bihar, the family survey records about three children per woman, a level India passed through in the nineteen seventies.",
            "In Goa, the same survey records one point one.",
            "In Kerala, Tamil Nadu and Andhra Pradesh, fertility sits at or below replacement, and in some districts the population is already shrinking without migration.",
            "India is now two demographic countries sharing one flag, one constitution, and one labour market.",
        ],
    ),
    dict(
        id="momentum",
        title="MOMENTUM",
        kicker="THE PYRAMID IS THE RESERVOIR",
        source="UN World Population Prospects 2024 (projections)",
        sentences=[
            "This is why.",
            "A population keeps growing after fertility falls, because the number of people entering childbearing ages was set decades earlier.",
            "India's median age is about twenty-nine, and roughly forty-five percent of Indians are under twenty-five.",
            "The base of the pyramid is not narrowing as fast as the top is ageing.",
            "For the next twenty years, the number of Indians in their twenties and thirties will grow by millions every year, even where births are fewer than deaths.",
        ],
    ),
    dict(
        id="dividend",
        title="THE DEMOGRAPHIC DIVIDEND",
        kicker="AND THE DIVIDEND ARISING",
        source="UN World Population Prospects 2024  •  Economic Survey 2023-24",
        sentences=[
            "The same fact that makes the population hard to sustain makes it valuable.",
            "For the next twenty-five years, India will have the largest workforce on Earth.",
            "The dependency ratio, the share of people too young or too old to work, is close to its lowest point in decades.",
            "If India can productively employ its working age population, this is a once-in-a-century economic opening.",
            "The prize is not theoretical. It is roughly one and a half billion workers.",
        ],
    ),
    dict(
        id="challenges",
        title="THE BILL ARRIVES",
        kicker="JOBS, CITIES, WATER",
        source="Economic Survey 2023-24  •  UN-Habitat  •  World Bank",
        sentences=[
            "And the bill arrives at the same time.",
            "The Economic Survey estimates India must create about seventy-eight lakh, that is nearly eight million, new jobs every single month, just to absorb new entrants.",
            "Urbanisation is accelerating: about thirty-six percent of Indians live in cities today.",
            "By twenty thirty-six, roughly six hundred million more people will live in Indian cities.",
            "Every one of them needs water, power, housing, sanitation, and a commute.",
            "Cities must absorb the equivalent of a million people every day.",
            "That is the planning challenge of the next thirty years.",
        ],
    ),
    dict(
        id="path",
        title="THE ROAD TO 1.7 BILLION",
        kicker="UN PROJECTION TO 2061",
        source="UN World Population Prospects 2024 (medium variant projection)",
        sentences=[
            "Where does it end?",
            "The United Nations projects India's population passing one point six seven billion around twenty fifty.",
            "It peaks at about one point seven billion in the early twenty sixties, and then, for the first time since independence, slowly declines.",
            "China peaked in twenty twenty-one. India follows roughly forty years behind.",
            "By twenty one hundred, India is projected back near one point five billion, still the largest country in the world, and still home to one in five people alive.",
        ],
    ),
    dict(
        id="close",
        title="WHAT THE NUMBER REQUIRES",
        kicker="CLOSING",
        source="",
        sentences=[
            "So the story of India's population is really two stories running at once.",
            "A growth story that is slowing: fertility at replacement, a peak within forty years, and a plateau that could last a century.",
            "And a scale story that is not slowing at all.",
            "One and a half billion people who must be housed, fed, employed and moved every single day.",
            "The demographic dividend and the demographic burden are the same fact seen from two ends.",
            "What India does with the next twenty-five years of that fact will determine the century for a fifth of humanity.",
        ],
    ),
]

# ---------------------------------------------------------------- outro

OUTRO = [
    ("1.47B", "Population of India today"),
    ("1.07B", "People added since 1947"),
    ("2.0", "Children per woman, from 5.9 in 1971"),
    ("1.70B", "Projected peak, early 2060s"),
]
