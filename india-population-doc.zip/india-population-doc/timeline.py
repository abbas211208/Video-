"""
Stage 2: turn the synthesised sentence wavs into a timeline + the mixed audio bed.

  python timeline.py work timeline.json narration.wav

Writes:
  timeline.json   per-scene start/duration and per-sentence start/duration
  narration.wav   the full voice track with the correct pauses
"""
import json
import math
import os
import sys
import wave
from array import array

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from content import SCENES, CREDITS  # noqa: E402

FPS = 24
SR = 22050
GAP = 0.34           # silence between sentences
SCENE_PAD_IN = 0.55  # silence before a scene's first sentence
SCENE_PAD_OUT = 1.05  # silence after a scene's last sentence

OUTRO_LINE = ("Population rising. India's demographic decade. "
              "One point four seven billion today, "
              "one point seven billion by the early twenty sixties, "
              "and one point five billion by the end of the century. "
              "The dividend and the burden are the same fact. "
              "What India does with the next twenty-five years will determine the century.")


def read_wav(path):
    with wave.open(path, "rb") as w:
        nch, sw, sr, n = w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()
        raw = w.readframes(n)
    assert sw == 2, f"{path}: expected 16-bit PCM"
    if nch == 2:
        a = array("h")
        a.frombytes(raw)
        mono = array("h", [int((a[i] + a[i + 1]) / 2) for i in range(0, len(a), 2)])
    else:
        a = array("h")
        a.frombytes(raw)
        mono = a
    if sr != SR:
        # crude linear resample
        ratio = sr / SR
        out_n = int(len(mono) / ratio)
        mono = array("h", [int(mono[int(i * ratio)]) for i in range(out_n)])
    return mono


def wav_duration(path):
    with wave.open(path, "rb") as w:
        return w.getnframes() / float(w.getframerate())


def write_wav(path, samples, sr=SR):
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(samples.tobytes())


def silence(n):
    return array("h", [0] * n)


def main():
    work = sys.argv[1]
    tl_out = sys.argv[2]
    aud_out = sys.argv[3]
    wav_dir = os.path.join(work, "wav")

    scenes_out = []
    voice = array("h")
    clock = 0.0

    all_scenes = list(SCENES) + [dict(id="outro", title="", kicker="", source=CREDITS)]

    for si, sc in enumerate(all_scenes):
        sents = list(sc["sentences"])
        if si == len(SCENES):
            sents = [OUTRO_LINE]

        voice += silence(int(SCENE_PAD_IN * SR))
        clock += SCENE_PAD_IN

        t_sent = clock
        sent_out = []
        for sj, text in enumerate(sents):
            sid = f"s{si:02d}_{sj:02d}"
            path = os.path.join(wav_dir, sid + ".wav")
            if not os.path.exists(path):
                raise SystemExit(f"missing wav: {path}")
            samples = read_wav(path)
            dur = len(samples) / float(SR)
            sent_out.append(dict(text=text, start=t_sent, dur=dur, id=sid))
            voice += samples
            t_sent += dur
            if sj < len(sents) - 1:
                voice += silence(int(GAP * SR))
                t_sent += GAP

        voice += silence(int(SCENE_PAD_OUT * SR))
        t_sent += SCENE_PAD_OUT

        scenes_out.append(dict(
            id=sc["id"],
            title=sc.get("title", ""),
            kicker=sc.get("kicker", ""),
            source=sc.get("source", ""),
            start=clock - SCENE_PAD_IN,
            duration=t_sent - (clock - SCENE_PAD_IN),
            sentences=sent_out,
        ))
        clock = t_sent

    write_wav(aud_out, voice)

    total = clock
    tl = dict(total=total, fps=FPS, scenes=scenes_out)
    with open(tl_out, "w", encoding="utf-8") as fh:
        json.dump(tl, fh, ensure_ascii=False, indent=1)

    # ---- subtitle file (SRT)
    srt_path = os.path.join(work, "subtitles.srt")
    idx = 1
    with open(srt_path, "w", encoding="utf-8") as fh:
        for sc in scenes_out:
            for s in sc["sentences"]:
                st, dur = s["start"], s["dur"]
                en = st + dur
                fh.write(f"{idx}\n")
                fh.write(f"{_ts(st)} --> {_ts(en)}\n")
                fh.write(s["text"] + "\n\n")
                idx += 1
    print(json.dumps(dict(total=total, sentences=idx - 1, subtitles=srt_path,
                          timeline=tl_out, audio=aud_out)))


def _ts(t):
    if t < 0:
        t = 0
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = int(t % 60)
    ms = int(round((t - int(t)) * 1000))
    if ms == 1000:
        ms = 0
        s += 1
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


if __name__ == "__main__":
    main()
