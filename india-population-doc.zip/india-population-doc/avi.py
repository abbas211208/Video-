"""
Pure-Python MJPEG-in-AVI muxer — a fallback for when no ffmpeg is available.

  python avi.py <frames_dir> <out.avi> <narration.wav> [fps]

Writes a RIFF/AVI file with an MJPEG video stream and a PCM audio stream,
interleaved. Playable in VLC, Windows Media Player, mpv and most editors.
"""
import io
import os
import struct
import sys
import wave

from PIL import Image


def riff_chunk(tag, data):
    pad = b"\x00" if len(data) & 1 else b""
    return tag + struct.pack("<I", len(data)) + data + pad


def jpeg_size(data):
    i = 2
    while i < len(data) - 9:
        if data[i] != 0xFF:
            i += 1
            continue
        m = data[i + 1]
        if m in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
            h, w = struct.unpack(">HH", data[i + 5:i + 9])
            return w, h
        if m in (0xD8, 0xD9) or 0xD0 <= m <= 0xD7:
            i += 2
            continue
        seglen = struct.unpack(">H", data[i + 2:i + 4])[0]
        i += 2 + seglen
    raise SystemExit("could not read JPEG dimensions")


def build_avi(frame_files, fps, audio_path=None, quality=88):
    vframes = []
    for p in frame_files:
        with Image.open(p) as im:
            buf = io.BytesIO()
            im.convert("RGB").save(buf, format="JPEG", quality=quality,
                                   subsampling=1)
            vframes.append(buf.getvalue())

    width, height = jpeg_size(vframes[0])
    nframes = len(vframes)

    audio_data = b""
    audio_fmt = None
    if audio_path:
        with wave.open(audio_path, "rb") as w:
            ch, sw, sr, n = w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()
            audio_data = w.readframes(n)
            audio_fmt = (ch, sw, sr)

    movi_body = bytearray()
    idx_entries = []
    offset = 4  # the 'movi' fourcc sits at the start of the LIST payload
    for fr in vframes:
        movi_body += riff_chunk(b"00dc", fr)
        idx_entries.append((b"00dc", 0x10, offset, len(fr)))
        offset += 8 + len(fr) + (len(fr) & 1)

    if audio_data:
        ch, sw, sr = audio_fmt
        bytes_per_sec = sw * ch * sr
        per_frame = max(1, int(round(bytes_per_sec / fps)))
        pos = 0
        while pos < len(audio_data):
            blk = audio_data[pos:pos + per_frame]
            pos += per_frame
            movi_body += riff_chunk(b"01wb", blk)
            idx_entries.append((b"01wb", 0x10, offset, len(blk)))
            offset += 8 + len(blk) + (len(blk) & 1)

    avih = struct.pack("<IIIIIIIIII4I",
                       int(1000000 / fps),   # microseconds per frame
                       0,                    # max bytes per second
                       0,                    # padding granularity
                       0x10,                 # flags: AVIF_HASINDEX
                       nframes,
                       0,                    # initial frames
                       1 + (1 if audio_data else 0),
                       0,                    # suggested buffer size
                       width, height,
                       0, 0, 0, 0)
    avih += struct.pack("<I", 0)

    strh_v = struct.pack("<4s4sIHHIIIIIIIIhhhh",
                         b"vids", b"MJPG", 0, 0, 0, 0, 1, fps, 0, nframes,
                         0xFFFFFFFF, 0, 0, 0, width, height)
    strf_v = struct.pack("<IiiHH4sIiiII", 40, width, height, 1, 24, b"MJPG",
                         width * height * 3, 0, 0, 0, 0)
    strl = riff_chunk(b"strh", strh_v) + riff_chunk(b"strf", strf_v)

    if audio_fmt:
        ch, sw, sr = audio_fmt
        blk_align = ch * sw
        strh_a = struct.pack("<4s4sIHHIIIIIIIIhhhh",
                             b"auds", b"\x00\x00\x00\x00", 0, 0, 0, 0, 1,
                             int(sr * blk_align), 0, len(audio_data) // blk_align,
                             0xFFFFFFFF, 0, 0, 0, 0, 0)
        strf_a = struct.pack("<IHHIIHHI", 1, ch, sr,
                             int(sr * blk_align), blk_align, sw, 0)
        strl += riff_chunk(b"strh", strh_a) + riff_chunk(b"strf", strf_a)

    hdrl = riff_chunk(b"avih", avih) + riff_chunk(b"LIST", b"strl" + strl)

    out = bytearray()
    out += b"RIFF" + struct.pack("<I", 0) + b"AVI "
    out += hdrl
    out += b"LIST" + struct.pack("<I", len(movi_body) + 4) + b"movi" + movi_body

    idx = bytearray()
    for tag, flags, off, size in idx_entries:
        idx += struct.pack("<4sIII", tag, flags, off, size)
    out += riff_chunk(b"idx1", bytes(idx))

    struct.pack_into("<I", out, 4, len(out) - 8)
    return bytes(out), width, height, nframes


def main():
    frames_dir = sys.argv[1]
    out_path = sys.argv[2]
    audio = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3] != "-" else None
    fps = int(sys.argv[4]) if len(sys.argv) > 4 else 24
    files = sorted(os.path.join(frames_dir, f) for f in os.listdir(frames_dir)
                   if f.lower().endswith(".png"))
    if not files:
        raise SystemExit("no frames found")
    data, w, h, n = build_avi(files, fps, audio)
    with open(out_path, "wb") as fh:
        fh.write(data)
    print(f"WROTE {out_path}  {w}x{h}  {n} frames  {len(data)/1e6:.1f} MB")


if __name__ == "__main__":
    main()
