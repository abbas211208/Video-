"""
Synthesise a soft ambient music bed (no external assets).

  python music.py narration.wav music.wav

The bed is a slow minor pad with a gentle pulse, ducking well under the
narration.
"""
import math
import os
import sys
import wave
from array import array

SR = 22050

# A minor -> F -> C -> G, one chord every 8 seconds (roughly).
CHORDS = [
    (110.00, 130.81, 164.81),   # Am
    (87.31, 130.81, 174.61),    # F
    (130.81, 164.81, 196.00),   # C
    (98.00, 123.47, 146.83),    # G
]
CHORD_SECONDS = 8.0
BED_GAIN = 0.085


def read_wav_mono(path):
    with wave.open(path, "rb") as w:
        nch, sw, sr, n = w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()
        raw = w.readframes(n)
    a = array("h")
    a.frombytes(raw)
    if nch == 2:
        a = array("h", [int((a[i] + a[i + 1]) / 2) for i in range(0, len(a), 2)])
    if sw != 2:
        raise SystemExit("expected 16-bit PCM")
    return a, sr


def main():
    narration, out = sys.argv[1], sys.argv[2]
    samples, sr = read_wav_mono(narration)
    if sr != SR:
        ratio = sr / SR
        out_n = int(len(samples) / ratio)
        samples = array("h", [samples[int(i * ratio)] for i in range(out_n)])
    n = len(samples)

    bed = array("h", [0] * n)
    for i in range(n):
        t = i / SR
        ci = int(t / CHORD_SECONDS) % len(CHORDS)
        chord = CHORDS[ci]
        local = t % CHORD_SECONDS
        # slow swell in and out within each chord
        env = math.sin(math.pi * local / CHORD_SECONDS) ** 1.4
        v = 0.0
        for f in chord:
            v += math.sin(2 * math.pi * f * t)
            v += 0.35 * math.sin(2 * math.pi * f * 2 * t)
        v /= (len(chord) * 1.35)
        # slow tremolo
        v *= 0.75 + 0.25 * math.sin(2 * math.pi * 0.07 * t)
        # gentle pulse every 2 seconds
        ph = t % 2.0
        pulse = math.exp(-ph * 7.0) * math.sin(2 * math.pi * 55.0 * t) * 0.25
        s = (v * env + pulse) * BED_GAIN
        # global fade in/out
        if t < 2.5:
            s *= t / 2.5
        if t > (n / SR) - 3.0:
            s *= max(0.0, ((n / SR) - t) / 3.0)
        bed[i] = int(max(-32767, min(32767, s * 32767)))

    with wave.open(out, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(bed.tobytes())
    print("WROTE", out, len(bed) / float(SR), "s")


if __name__ == "__main__":
    main()
