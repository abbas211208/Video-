"""
Stage 1: synthesise narration, measure it, build the timeline.

  python build_audio.py voices.json work

Stage 2 (separate process) renders frames, because synthesis needs the
Windows speech engine while rendering is pure Pillow.
"""
import json
import os
import struct
import sys
import wave

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from content import SCENES, OUTRO, TITLE, SUBTITLE, CREDITS  # noqa: E402

FPS = 24

# gap between sentences, and lead-in/lead-out padding per scene
GAP = 0.34
SCENE_PAD_IN = 0.55
SCENE_PAD_OUT = 1.05


def wav_duration(path):
    with wave.open(path, "rb") as w:
        n = w.getnframes()
        sr = w.getframerate()
        return n / float(sr)


def main():
    voices_cfg = json.load(open(sys.argv[1], encoding="utf-8"))
    work = sys.argv[2]
    wav_dir = os.path.join(work, "wav")
    os.makedirs(wav_dir, exist_ok=True)

    # ---- collect every sentence that needs speaking
    items = []
    for si, sc in enumerate(SCENES):
        for sj, s in enumerate(sc["sentences"]):
            items.append(dict(id=f"s{si:02d}_{sj:02d}", text=s, scene=si))
    # outro narration
    outro_line = ("Population rising. India's demographic decade. "
                  "One point four seven billion today, "
                  "one point seven billion by the early twenty sixties, "
                  "and one point five billion by the end of the century. "
                  "The dividend and the burden are the same fact. "
                  "What India does with the next twenty-five years will determine the century.")
    items.append(dict(id="s99_00", text=outro_line, scene=len(SCENES)))
    outro_scenes = [dict(id="outro", title="", kicker="", source=CREDITS,
                          sentences=[outro_line], duration=0.0)]

    # ---- write the request file the PowerShell synthesiser reads
    req = dict(rate=voices_cfg.get("rate", 0),
               volume=voices_cfg.get("volume", 100),
               voice=voices_cfg.get("voice"),
               sentences=[dict(id=it["id"], text=it["text"]) for it in items])
    req_path = os.path.join(work, "tts_request.json")
    with open(req_path, "w", encoding="utf-8") as fh:
        json.dump(req, fh, ensure_ascii=False, indent=1)
    print("wrote", req_path, file=sys.stderr)

    # ---- the shell script that runs the synthesiser
    print("TTS_REQUEST_READY", req_path, wav_dir)


if __name__ == "__main__":
    main()
