param(
  [Parameter(Mandatory=$true)][string]$InFile,
  [Parameter(Mandatory=$true)][string]$OutDir
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Speech

$data = Get-Content -Raw -Encoding UTF8 $InFile | ConvertFrom-Json

$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer

$voices = $synth.GetInstalledVoices() | ForEach-Object { $_.VoiceInfo.Name }
Write-Output ("AVAILABLE_VOICES::" + ($voices -join "|"))

$chosen = $null
if ($data.voice -and ($voices -contains $data.voice)) {
  $chosen = $data.voice
} else {
  foreach ($pref in @("Microsoft David Desktop","Microsoft Mark Desktop","Microsoft Zira Desktop",
                      "Microsoft David","Microsoft Zira","Microsoft Mark","David","Zira","Mark",
                      "Microsoft Ravi Desktop","Microsoft Ravi","Google US English","Samantha")) {
    if ($voices -contains $pref) { $chosen = $pref; break }
  }
}
if (-not $chosen) { $chosen = $voices[0] }
Write-Output ("CHOSEN_VOICE::" + $chosen)

$synth.SelectVoice($chosen)
$synth.Rate = [int]$data.rate
$synth.Volume = [int]$data.volume
$synth.SetOutputToNull()

$manifest = @()
foreach ($s in $data.sentences) {
  $path = Join-Path $OutDir ($s.id + ".wav")
  if (Test-Path $path) { Remove-Item $path -Force }
  $synth.SetOutputToWaveFile($path)
  $synth.Speak([string]$s.text)
  $synth.SetOutputToNull()
  $manifest += [pscustomobject]@{ id = $s.id; file = $path }
}
$manifest | ConvertTo-Json -Depth 3 | Set-Content -Encoding UTF8 (Join-Path $OutDir "manifest.json")
Write-Output ("SYNTHESIZED::" + $manifest.Count)
