"""
One-shot build: narration -> timeline -> music -> frames -> video.

  python build_all.py [--work work] [--out Population-Rising-India.mp4] [--skip-render]

Runs every stage in order. Any stage failing aborts the build with a clear
message rather than producing a half-finished video.
"""
import argparse
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def run(cmd, label):
    print(f"\n--- {label} ---", flush=True)
    print("> " + " ".join(cmd), flush=True)
    t0 = time.time()
    r = subprocess.run(cmd, cwd=HERE)
    print(f"--- {label}: exit {r.returncode} in {time.time()-t0:.1f}s", flush=True)
    if r.returncode != 0:
        raise SystemExit(f"stage failed: {label}")
    return r.returncode


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work", default="work")
    ap.add_argument("--out", default="Population-Rising-India.mp4")
    ap.add_argument("--skip-render", action="store_true")
    ap.add_argument("--install-deps", action="store_true")
    args = ap.parse_args()

    work = os.path.join(HERE, args.work)
    wav_dir = os.path.join(work, "wav")
    frames = os.path.join(work, "frames")
    os.makedirs(wav_dir, exist_ok=True)

    if args.install_deps:
        run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check",
             "pillow", "numpy", "imageio-ffmpeg"], "install dependencies")

    run([sys.executable, os.path.join(HERE, "make_script.py"), "SCRIPT.md"],
        "narration document")
    run([sys.executable, os.path.join(HERE, "build_audio.py"), "voices.json", work],
        "build TTS request")

    ps = os.path.join(HERE, "synth.ps1")
    run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", ps,
         "-InFile", os.path.join(work, "tts_request.json"), "-OutDir", wav_dir],
        "synthesise narration")

    run([sys.executable, os.path.join(HERE, "timeline.py"), work,
         os.path.join(work, "timeline.json"), os.path.join(work, "narration.wav")],
        "timeline + subtitles")
    run([sys.executable, os.path.join(HERE, "music.py"),
         os.path.join(work, "narration.wav"), os.path.join(work, "music.wav")],
        "music bed")

    if not args.skip_render:
        run([sys.executable, os.path.join(HERE, "render.py"),
             os.path.join(work, "timeline.json"), frames], "render frames")

    run([sys.executable, os.path.join(HERE, "assemble.py"), work,
         os.path.join(work, "timeline.json"), os.path.join(work, "narration.wav"),
         os.path.join(HERE, args.out)], "assemble video")

    for name in (args.out, os.path.splitext(args.out)[0] + ".avi"):
        p = os.path.join(HERE, name)
        if os.path.exists(p):
            print(f"\nOUTPUT {name}  {os.path.getsize(p)/1e6:.1f} MB")

    with open(os.path.join(work, "timeline.json"), encoding="utf-8") as fh:
        tl = json.load(fh)
    print(f"\nDURATION {tl['total']:.1f}s   scenes {len(tl['scenes'])}")


if __name__ == "__main__":
    main()
