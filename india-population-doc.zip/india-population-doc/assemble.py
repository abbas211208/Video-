"""
Stage 3: assemble frames + narration into the final video.

  python assemble.py work timeline.json narration.wav out.mp4

Prefers ffmpeg (H.264 MP4, burned-in subtitles). If no ffmpeg is available it
falls back to the pure-Python MJPEG/AVI muxer in avi.py, with the subtitle
file delivered alongside.
"""
import json
import os
import shutil
import subprocess
import sys


def find_ffmpeg():
    try:
        import imageio_ffmpeg
        p = imageio_ffmpeg.get_ffmpeg_exe()
        if p and os.path.exists(p):
            return p
    except Exception:
        pass
    p = shutil.which("ffmpeg") or shutil.which("ffmpeg.exe")
    if p:
        return p
    for base in (r"C:\Program Files", r"C:\Program Files (x86)",
                 os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\WinGet\Packages")):
        if not os.path.isdir(base):
            continue
        for root, dirs, files in os.walk(base):
            for f in files:
                if f.lower() == "ffmpeg.exe":
                    return os.path.join(root, f)
            if root.count(os.sep) - base.count(os.sep) > 4:
                dirs[:] = []
    return None


def srt_filter(path):
    return (f"subtitles='{path.replace(os.sep, '/')}':"
            "force_style='FontName=Segoe UI,FontSize=17,"
            "PrimaryColour=&H00FFFFFF,OutlineColour=&H99000000,"
            "BorderStyle=3,Outline=2,Shadow=0,MarginV=42'")


def main():
    work, tl_path, wav, out = sys.argv[1:5]
    tl = json.load(open(tl_path, encoding="utf-8"))
    fps = tl.get("fps", 24)
    frames = os.path.join(work, "frames")
    srt = os.path.join(work, "subtitles.srt")
    music = os.path.join(work, "music.wav")

    ff = find_ffmpeg()
    if ff:
        print("ffmpeg:", ff, file=sys.stderr)
        inputs = ["-framerate", str(fps), "-i", os.path.join(frames, "f%05d.png"),
                  "-i", wav]
        mix = "[1:a]volume=1.0[nar];"
        if os.path.exists(music):
            inputs += ["-i", music]
            mix += ("[2:a]volume=0.55[bed];"
                    "[nar][bed]amix=inputs=2:duration=first:dropout_transition=0[aout]")
        else:
            mix += "[nar]anull[aout]"
        cmd = [ff, "-y"] + inputs + [
            "-filter_complex", mix,
            "-vf", srt_filter(srt),
            "-map", "0:v", "-map", "[aout]",
            "-c:v", "libx264", "-preset", "medium", "-crf", "19",
            "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "160k",
            "-movflags", "+faststart",
            "-r", str(fps),
            out,
        ]
        print(" ".join(cmd), file=sys.stderr)
        subprocess.run(cmd, check=True)
        print("WROTE", out)
        return

    print("no ffmpeg found — writing AVI instead", file=sys.stderr)
    import avi
    files = sorted(os.path.join(frames, f) for f in os.listdir(frames)
                   if f.lower().endswith(".png"))
    data, w, h, n = avi.build_avi(files, fps, wav)
    avi_out = os.path.splitext(out)[0] + ".avi"
    with open(avi_out, "wb") as fh:
        fh.write(data)
    print(f"WROTE {avi_out}  {w}x{h}  {n} frames  {len(data)/1e6:.1f} MB")


if __name__ == "__main__":
    main()
