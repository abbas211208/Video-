"""
Emit SCRIPT.md — the narration as a readable document — from content.py.

  python make_script.py SCRIPT.md
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from content import CREDITS, SCENES, TITLE, SUBTITLE  # noqa: E402


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else "SCRIPT.md"
    lines = []
    lines.append(f"# {TITLE}")
    lines.append(f"### {SUBTITLE}")
    lines.append("")
    lines.append("A documentary short on India's population growth — what it was, "
                 "why it happened, where it is going, and what it requires.")
    lines.append("")
    lines.append(f"*{CREDITS}*")
    lines.append("")
    lines.append("---")
    lines.append("")
    for i, sc in enumerate(SCENES, 1):
        lines.append(f"## {i}. {sc['title']}")
        if sc.get("kicker"):
            lines.append(f"*On screen: {sc['kicker']}*")
        lines.append("")
        for s in sc["sentences"]:
            lines.append(s)
            lines.append("")
        if sc.get("source"):
            lines.append(f"> On-screen source: {sc['source']}")
            lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## Outro")
    lines.append("")
    lines.append("Population rising. India's demographic decade. One point four seven "
                 "billion today, one point seven billion by the early twenty sixties, "
                 "and one point five billion by the end of the century. The dividend "
                 "and the burden are the same fact. What India does with the next "
                 "twenty-five years will determine the century.")
    lines.append("")
    with open(out, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))
    print("WROTE", out)


if __name__ == "__main__":
    main()
