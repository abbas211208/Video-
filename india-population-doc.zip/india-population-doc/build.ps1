param(
  [string]$Work = "work",
  [string]$Out  = "Population-Rising-India.mp4",
  [switch]$SkipRender,
  [switch]$SkipDeps
)

$ErrorActionPreference = "Continue"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

function Step($n) { Write-Host $n -ForegroundColor Cyan }

$workPath = Join-Path $root $Work
New-Item -ItemType Directory -Force -Path $workPath | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $workPath "wav") | Out-Null

if (-not $SkipDeps) {
  Step "== 0/7  dependencies =="
  python -m pip install --disable-pip-version-check --quiet pillow numpy imageio-ffmpeg 2>&1 | Select-Object -Last 3
  python -c "import PIL, numpy; print('PIL', PIL.__version__, '| numpy', numpy.__version__)"
}

Step "== 1/7  narration document =="
python make_script.py SCRIPT.md

Step "== 2/7  building TTS request =="
python build_audio.py voices.json $workPath

Step "== 3/7  synthesising narration (Windows SAPI) =="
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root "synth.ps1") `
    -InFile (Join-Path $workPath "tts_request.json") -OutDir (Join-Path $workPath "wav")

Step "== 4/7  building timeline + subtitles =="
python timeline.py $workPath (Join-Path $workPath "timeline.json") (Join-Path $workPath "narration.wav")

Step "== 5/7  generating music bed =="
python music.py (Join-Path $workPath "narration.wav") (Join-Path $workPath "music.wav")

if (-not $SkipRender) {
  Step "== 6/7  rendering frames =="
  python render.py (Join-Path $workPath "timeline.json") (Join-Path $workPath "frames")
} else {
  Step "== 6/7  rendering frames -- SKIPPED =="
}

Step "== 7/7  assembling video =="
python assemble.py $workPath (Join-Path $workPath "timeline.json") (Join-Path $workPath "narration.wav") (Join-Path $root $Out)

Write-Host "" -ForegroundColor DarkGray
Get-ChildItem $root -Filter "*.mp4" | ForEach-Object { Write-Host ("MP4: " + $_.FullName + "  " + [math]::Round($_.Length/1MB,1) + " MB") }
Get-ChildItem $root -Filter "*.avi" | ForEach-Object { Write-Host ("AVI: " + $_.FullName + "  " + [math]::Round($_.Length/1MB,1) + " MB") }
Write-Host "DONE" -ForegroundColor Green
