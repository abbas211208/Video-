import sys, shutil, subprocess, importlib

print("python:", sys.version)
print("executable:", sys.executable)
for m in ("PIL", "numpy", "imageio_ffmpeg", "matplotlib", "pyttsx3"):
    try:
        mod = importlib.import_module(m)
        print("OK  ", m, getattr(mod, "__version__", ""))
    except Exception as e:
        print("MISS", m, type(e).__name__)
for b in ("ffmpeg", "ffprobe", "magick", "convert"):
    print("bin ", b, shutil.which(b))
try:
    import imageio_ffmpeg
    print("bundled ffmpeg:", imageio_ffmpeg.get_ffmpeg_exe())
except Exception as e:
    print("bundled ffmpeg: n/a", e)
